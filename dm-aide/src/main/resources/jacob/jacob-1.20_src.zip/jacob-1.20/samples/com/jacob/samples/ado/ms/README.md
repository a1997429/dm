This is the WFC equivalent of the JACOB ADO example.

This code must be compiled with JVC and run with JVIEW.

The file testms.java has been renamed to tesetms.java.txt
because most folks building this application will
not have the MS JVM installed and will get compiler 
warnings.  The MS JVM is going away eventually
so this whole test will eventually go away.