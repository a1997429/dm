#pragma once

// �ο�: https://blog.csdn.net/Bryan_QAQ/article/details/92798098

_declspec(dllexport) int add(int a, int b);

_declspec(dllexport) int max(int a, int b);

