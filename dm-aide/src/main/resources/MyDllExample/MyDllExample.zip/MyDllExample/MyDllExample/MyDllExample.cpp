#include "MyDllExample.h"

int Add(int a, int b) {
	return a + b;
}

int Max(int a, int b) {
	return a > b ? a : b;
}

int ReturnValue(){
	int a = 88;
	return a;
}

int ReturnParam(int a, int& b, int& c){
	int d = 3;
	b = a + 1;
	c = a + 2;
	return a + d;
}
