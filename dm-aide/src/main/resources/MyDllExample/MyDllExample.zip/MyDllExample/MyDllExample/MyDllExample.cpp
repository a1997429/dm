#include "MyDllExample.h"

int add(int a, int b) {
	return a + b;
}

int max(int a, int b) {
	return a > b ? a : b;
}

