#include <iostream>
using namespace std;

#include "MyDllExample.h"

int main() {
	int a = 5, b = 24;

	int c = Add(a, b);
	cout << c << endl;

	int d = Max(a, b);
	cout << d << endl;

	return 0;
}


